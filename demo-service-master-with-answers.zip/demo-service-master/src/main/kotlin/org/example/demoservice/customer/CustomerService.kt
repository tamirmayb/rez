package org.example.demoservice.customer

import org.example.demoservice.api.dto.PaginatedResponse
import org.example.demoservice.api.v1.model.ApiCustomerList
import org.example.demoservice.api.v1.model.RegistrationRequest
import org.example.demoservice.api.v1.model.toApi
import org.example.demoservice.util.Paginator
import org.springframework.stereotype.Service

@Service
class CustomerService(
    private val customerRepository: CustomerRepository,
    private val customerNumberProvider: CustomerNumberProvider,
) {

    fun registerCustomer(tenantId: String, registrationRequest: RegistrationRequest): Customer {
        val customerNumber = nextCustomerNumber()
        val customer = Customer(
            tenantId = tenantId,
            customerNumber = customerNumber,
            email = registrationRequest.email,
            name = registrationRequest.name,
            phoneNumber = registrationRequest.phoneNumber,
            address = registrationRequest.address
        )
        return customerRepository.save(customer)
    }

    fun getCustomers(tenantId: String, pageNumber: Int = 1, pageSize: Int = 10): PaginatedResponse {
        val results: List<Customer> = customerRepository.findAllByTenantId(tenantId)

        val paginatedCustomers: List<Customer> = Paginator(results, pageSize).getPageItems(pageNumber)
        val toApi: ApiCustomerList = paginatedCustomers.toApi()
        return PaginatedResponse(
            toApi,
            pageNumber,
            toApi.customers.size,

        )
    }

    fun getCustomer(tenantId: String, customerNumber: String): Customer {
        return customerRepository.findByTenantIdAndCustomerNumber(tenantId, customerNumber)
            ?: throw CustomerNotFoundException(tenantId, customerNumber)
    }

    private fun nextCustomerNumber(): String { //t4
        val nextCustomerNumber = customerNumberProvider.nextCustomerNumber()
        if (customerRepository.existsByCustomerNumber(nextCustomerNumber)) {
            return nextCustomerNumber()
        }
        return nextCustomerNumber
    }
}
