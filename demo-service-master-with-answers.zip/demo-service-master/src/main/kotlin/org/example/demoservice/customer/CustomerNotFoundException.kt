package org.example.demoservice.customer

import org.apache.logging.log4j.LogManager

private val logger = LogManager.getLogger(CustomerNotFoundException::class.java)

@Suppress("serial")
class CustomerNotFoundException(
    tenantId: String,
    customerNumber: String,
) : RuntimeException("customer $customerNumber not found in tenant $tenantId") {
    init {
        logger.error("customer $customerNumber not found in tenant $tenantId")
    }
}

