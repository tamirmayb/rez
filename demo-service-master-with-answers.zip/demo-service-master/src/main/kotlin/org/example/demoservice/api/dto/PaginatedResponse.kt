package org.example.demoservice.api.dto

import org.example.demoservice.api.v1.model.ApiCustomerList

class PaginatedResponse(
    val results: ApiCustomerList,
    val page: Int,
    val total: Int
)