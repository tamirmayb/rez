package org.example.demoservice.util

class Paginator<T>(
    private val items: List<T>,
    private val itemsPerPage: Int,
) {
    private var currentPage: Int = 0
    private val totalPages: Int = if (items.isEmpty()) 1 else (items.size + itemsPerPage - 1) / itemsPerPage

    fun getPageItems(currentPage: Int): List<T> {
        this.currentPage = if (currentPage < 1) 0 else currentPage - 1
        return getCurrentPageItems()
    }

    fun getCurrentPageItems(): List<T> {
        try {
            val startIndex = currentPage * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, items.size)
            return items.subList(startIndex, endIndex)
        } catch (_: Exception) {
            return emptyList()
        }
    }

    fun nextPage(): List<T> {
        if (currentPage < totalPages - 1) {
            currentPage++
        }
        return getCurrentPageItems()
    }

    fun previousPage(): List<T> {
        if (currentPage > 0) {
            currentPage--
        }
        return getCurrentPageItems()
    }

    fun goToPage(page: Int): List<T> {
        if (page in 0 until totalPages) {
            currentPage = page
        }
        return getCurrentPageItems()
    }

    fun getCurrentPage(): Int = currentPage + 1

    fun getTotalPages(): Int = totalPages
}

//fun main() {
//    val items = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
//    val paginator = Paginator(items, 3)
//
//    println("Page ${paginator.getCurrentPage()} of ${paginator.getTotalPages()}: ${paginator.getCurrentPageItems()}")
//    println("Next Page: ${paginator.nextPage()}")
//    println("Next Page: ${paginator.nextPage()}")
//    println("Previous Page: ${paginator.previousPage()}")
//    println("Go to Page 1: ${paginator.goToPage(0)}")
//    println("Go to Page 4: ${paginator.goToPage(3)}")
//}
